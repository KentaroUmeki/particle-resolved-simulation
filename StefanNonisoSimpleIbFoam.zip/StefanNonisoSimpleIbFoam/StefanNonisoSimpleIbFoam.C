/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | foam-extend: Open Source CFD
   \\    /   O peration     | Version:     3.2
    \\  /    A nd           | Web:         http://www.foam-extend.org
     \\/     M anipulation  | For copyright notice see file Copyright
-------------------------------------------------------------------------------
License
    This file is part of foam-extend.

    foam-extend is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or (at your
    option) any later version.

    foam-extend is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with foam-extend.  If not, see <http://www.gnu.org/licenses/>.

Application
    simpleIbFoam

Description
    Steady-state solver for incompressible, turbulent flow
    with immersed boundary support.

Author
    Hrvoje Jasak, Wikki Ltd.  All rights reserved

\*---------------------------------------------------------------------------*/

#include "fvCFD.H"
#include "simpleControl.H"

#include "immersedBoundaryFvPatch.H"
#include "immersedBoundaryAdjustPhi.H"

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

int main(int argc, char *argv[])
{
#   include "setRootCase.H"
#   include "createTime.H"
#   include "createMesh.H"
    simpleControl simple(mesh);
    
#   include "createIbMasks.H"
#   include "createFields.H"
#   include "initContinuityErrs.H"

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

    Info<< "\nStarting time loop\n" << endl;

    while (simple.loop())
    {
        Info<< "Time = " << runTime.timeName() << nl << endl;


        // Pressure-velocity SIMPLE corrector
        {
       	rho = atmPressure*MWAir/(gasConstant*T);   
		cp=pos(T-templimit)*(R*(a5high/pow(T,2)+a6high/T+((((a4high*T+a3high)*T+a2high)*T+a1high)*T+a0high)))+neg(T-templimit)*(R*(a5low/pow(T,2)+a6low/T+((((a4low*T+a3low)*T+a2low)*T+a1low)*T+a0low)));
		scalarField Tmag = mag((T.internalField()));
		scalarField cpmag = mag((cp.internalField()));
		mu = As*sqrt(T)/(1+Ts/T); //corrected on 2018,8,6    
	   //    kappa=mu*(cp-R)*(1.32+1.77*R/(cp-R));
		kappa=conductivityCoeff*pow(T,0.717);
       //	 kappa=kappa1*pow(T,2)+kappa2*pow(T,1)+kappa3;//changed using the empirical formula for the range 2018,8,6  
	      volScalarField kappaBycp =kappa/cp;

#           include "UEqn.H"
#	include "TEqn.H"
#           include "pEqn.H"
	/*label patchi = mesh.boundaryMesh().findPatchID("out");
	scalarField kappaIbSphere = kappa.boundaryField()[patchi].patchInternalField();
	const polyPatch& cPatch = mesh.boundaryMesh()[patchi]; 
	scalar kappaAverageIbSphere= 0.0;
	forAll(cPatch,facei)
	{
 		kappaAverageIbSphere =gSum(kappaIbSphere[facei]);
	}*/
	//Info << "IbPatch conductivity average " << kappaAverageIbSphere << endl; 


        }

       // turbulence->correct();

        runTime.write();

        Info<< "ExecutionTime = " << runTime.elapsedCpuTime() << " s"
            << "  ClockTime = " << runTime.elapsedClockTime() << " s"
            << nl << endl;
	 /*label patchi = mesh.boundaryMesh().findPatchID("out");
        scalarField TIbSphere = T.boundaryField()[patchi].patchInternalField();
        const polyPatch& cPatch = mesh.boundaryMesh()[patchi]; 
        scalar TAverageIbSphere= 0.0;
        forAll(cPatch,facei)
        {
                TAverageIbSphere +=TIbSphere[facei];
        }
       
      std::ofstream file;
      file.open ("results.txt", std::ofstream::out | std::ofstream::app);
      file << runTime.timeName() << " " << TAverageIbSphere << std::endl << "\n";
      file << nl << endl;
      file.close();*/
/* Info << "IbPatch conductivity average at time " <<  runTime.timeName() << " s"
	     << " is " << kappaAverageIbSphere << " m"<< endl;*/
    }

    Info<< "End\n" << endl;

    return 0;
}


// ************************************************************************* //
